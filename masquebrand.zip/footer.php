<div class="container p-10">
    <div class="row-hr"></div>
</div>

<footer id="footer">
    <div class="container d-flex content_footer justify-space-between">

        <div class="col_footer">
            <h4>Clientes</h4>

            <ul>
                <li><a href="">APPLICATION FOR PAYMENT</a></li>
                <li><a href="">PAYMENT</a></li>
            </ul>
        </div>
        <div class="col_footer">
            <h4>Contatos</h4>

            <ul>
                <li><a href="">contato@brandmasquee.com</a></li>
                <li><a href="">(19) 9 9999-9999</a></li>
                <li><a href="">(19) 9 9999-9999</a></li>
            </ul>
        </div>
        <div class="col_footer">
            <h4>Redes sociais</h4>

            <ul class="social_footer">
                <li><a href=""><i class="bi bi-facebook"></i></a></li>
                <li><a href=""><i class="bi bi-instagram"></i></a></li>
                <li><a href=""><i class="bi bi-youtube"></i></a></li>
            </ul>
        </div>
    </div>

    <div class="container text-center">
        <p class="color-white p-10">Brandmasque</p>
    </div>
</footer>

<a href="#" class="btn_float">
    <i class="bi bi-telephone"></i>
</a>

<?php wp_footer(); ?>
</body>
</html>
