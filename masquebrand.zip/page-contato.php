<?php
get_header();
//Template Name: Contato
?>

<main class="content_page">

    <section>
        <div class="container d-flex section-default">
            <div class="f-50 ">
                <h3 class="subtitle">Nosso</h3>
                <h2 class="title-second m-b-60">Contato</h2>

                <p class="text-default m-b-60">Entre em contato conosco e vamos conversar sobre seu projeto</p>


                <form action="" class="form_contact">
                    <input type="text" name="" id="">
                    <input type="text" name="" id="">
                    <div class="d-flex">
                        <button type="submit" class="btn-default w-100 d-flex justify-space-between color-white btn-icon align-items-center">ENVIAR <span><i class="bi bi-arrow-right"></i></span></button>
                    </div>
                </form>

                
            </div>
            <div class="f-50 d-flex right_content justify-flex-end">
                <img src="http://localhost/wordpress/masquebrand/wp-content/themes/masquebrand/assets/img/imag.jpg" alt="" class="">
            </div>
        </div>
    </section>

</main>

<?php
get_footer();
?>
